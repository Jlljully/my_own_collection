Role Name
=========
single_task_role


Example Playbook
----------------

---
- name: test my role
  hosts: localhost
  roles:
    - single_task_role

    
License
-------
MIT

Author Information
------------------

Maksimova Yulia
